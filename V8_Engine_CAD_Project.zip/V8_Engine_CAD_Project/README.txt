V8 ENGINE CAD PROJECT — STARTER PACKAGE
=======================================

Included:
- V8_Engine_Assembly.scad : editable parametric OpenSCAD source
- README.txt              : this guide

Software:
- OpenSCAD (free): https://openscad.org/

How to view:
1. Open V8_Engine_Assembly.scad in OpenSCAD.
2. Press F5 for preview.
3. Press F6 for a full render.
4. Use View > Show Axes / Show Scale as helpful.

How to export:
- File > Export > Export as STL after rendering.
- The provided script displays the engine as a single conceptual assembly.
- For print-ready individual parts, isolate one module at a time and export separately.

Model scope:
- Educational, non-combustion V8 display concept.
- Includes block, two cylinder-bank forms, heads, intake, exhaust, simplified crankshaft,
  flywheel, approximate pistons/rods, and a display stand.
- It is not a mechanically validated or fully constrained engine assembly. In particular,
  the crankshaft throws and rod positions are illustrative and do not guarantee that all
  pistons move without collisions.

Tolerance notes:
- The code uses a nominal piston-to-bore diametral allowance of about 0.35 mm as a
  starting visual fit. Actual FDM clearances depend on printer calibration, material,
  orientation, and slicer settings.
- Print a tolerance coupon before committing to a full assembly.
- For a moving version, redesign the crankshaft journals, connecting-rod big ends,
  wrist pins, bearings, and piston guides as separate, tested parts.
- Suggested prototype clearances are starting values only, not guarantees:
  0.2–0.3 mm per side for sliding/rotating FDM interfaces; test first.

Suggested next steps:
1. Validate the cylinder-bank and crankshaft geometry.
2. Add separate bearing caps and real crank pins.
3. Constrain the assembly in a CAD tool that supports joints/motion simulation.
4. Run interference checks and export individual STL files.
5. Test-fit a small piston/bore sample before printing the complete engine.

Important:
This is a starter CAD source model, not a finished production engine design, and it is
not intended for combustion, fuel, or high-speed operation.
